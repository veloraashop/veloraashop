---
name: Veloraa Luxury Atelier
colors:
  surface: '#fff8f8'
  surface-dim: '#e5d6db'
  surface-bright: '#fff8f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff0f4'
  surface-container: '#f9eaef'
  surface-container-high: '#f3e5e9'
  surface-container-highest: '#eddfe3'
  on-surface: '#211a1d'
  on-surface-variant: '#534247'
  inverse-surface: '#362e32'
  inverse-on-surface: '#fcedf2'
  outline: '#867277'
  outline-variant: '#d8c1c6'
  surface-tint: '#974161'
  primary: '#8b3758'
  on-primary: '#ffffff'
  primary-container: '#a94f70'
  on-primary-container: '#ffebef'
  inverse-primary: '#ffb0c9'
  secondary: '#7e5262'
  on-secondary: '#ffffff'
  secondary-container: '#fec5d8'
  on-secondary-container: '#7a4f5f'
  tertiary: '#714b3e'
  on-tertiary: '#ffffff'
  tertiary-container: '#8c6354'
  on-tertiary-container: '#ffebe5'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9e2'
  primary-fixed-dim: '#ffb0c9'
  on-primary-fixed: '#3e001e'
  on-primary-fixed-variant: '#7a294a'
  secondary-fixed: '#ffd9e4'
  secondary-fixed-dim: '#efb7ca'
  on-secondary-fixed: '#31101e'
  on-secondary-fixed-variant: '#633b4a'
  tertiary-fixed: '#ffdbcf'
  tertiary-fixed-dim: '#eebbaa'
  on-tertiary-fixed: '#2f1409'
  on-tertiary-fixed-variant: '#623e31'
  background: '#fff8f8'
  on-background: '#211a1d'
  surface-variant: '#eddfe3'
typography:
  display-hero:
    fontFamily: Vazirmatn
    fontSize: 3.5rem
    fontWeight: '700'
    lineHeight: 4.5rem
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Vazirmatn
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 3.125rem
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Vazirmatn
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 3.25rem
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Vazirmatn
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: '0'
  headline-md:
    fontFamily: Vazirmatn
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2.25rem
  headline-sm:
    fontFamily: Vazirmatn
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.875rem
  title-md:
    fontFamily: Vazirmatn
    fontSize: 1.125rem
    fontWeight: '500'
    lineHeight: 1.75rem
  body-lg:
    fontFamily: Vazirmatn
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 2rem
  body-md:
    fontFamily: Vazirmatn
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-sm:
    fontFamily: Vazirmatn
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.5rem
  label-lg:
    fontFamily: Vazirmatn
    fontSize: 0.9375rem
    fontWeight: '500'
    lineHeight: 1.375rem
  label-md:
    fontFamily: Vazirmatn
    fontSize: 0.8125rem
    fontWeight: '500'
    lineHeight: 1.25rem
  price-numeral:
    fontFamily: Vazirmatn
    fontSize: 1.25rem
    fontWeight: '700'
    lineHeight: 1.5rem
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
---

## Brand & Style

The design system embodies modern Persian haute-couture beauty: an editorial, magazine-grade e-commerce experience curated for discerning clientele. The aesthetic combines refined editorial minimalism with soft tactile warmth, rejecting saturated or juvenile cosmetics styling in favor of poise, balance, and quiet prestige.

### Aesthetic Principles
- **Editorial High-Fashion Layouts:** Generous, intentional whitespace, asymmetrical product staging, and razor-sharp typographic hierarchy echoing global luxury publications.
- **Warm Tactility:** Surfaces reference handmade cotton rag paper, alabaster, and spun rose gold, rather than sterile clinical grays or harsh synthetic pinks.
- **Deliberate Restraint:** Accents in rose gold and deep plum appear with precise intent—underlining craftsmanship, guiding checkout flow, and elevating product curation without visual clutter.
- **RTL-Native Poise:** Designed natively for Persian script, ensuring optical balance, fluid baseline alignment, and elegant punctuation cadence.

## Colors

The chromatic architecture relies on nuanced contrasts between warm porcelain grounds, deep floral plums, and subtle mineral metallics.

### Palette Architecture
- **Primary (`#A94F70` — Deep Rose):** Expressive interactive lead. Reserved for primary purchase triggers, active tab states, and key navigational highlights.
- **Secondary (`#512B3A` — Deep Plum):** The authoritative editorial anchor. Employed for high-contrast headline typography, luxury branding marks, and high-emphasis states.
- **Tertiary (`#B88A7A` — Burnished Rose-Gold):** Metallic highlight. Utilized for VIP badges, award markers, delicate dividers, and subtle star-rating fills.
- **Soft Accent Tier:**
  - Rose Tint (`#D88FA7`): Subtle state changes and soft badge fills.
  - Soft Blush (`#F0D3DC`): Active borders, secondary button outlines, chip backgrounds.
  - Powder Pink (`#F5E6EA`): Subtle input fills and seasonal promotional panels.
- **Neutral & Structural Foundations:**
  - Warm Ivory (`#FFFCF8`): Primary canvas backdrop, delivering organic warmth.
  - Porcelain White (`#FFFFFF`): Elevated card containers and floating dialogue sheets.
  - Soft Warm Gray (`#81767A`): Body copy, breadcrumbs, and inactive label states.
  - Muted Hairline Border (`#EFE6E9`): Structure lines, cards, and quiet separators.

## Typography

The typographic system utilizes **Vazirmatn** (with **Estedad** fallback) configured for right-to-left editorial flow. 

### Persian Typographic Standards
- **Optical Balance:** Persian script requires taller baseline-to-ascender ratios than Latin alphabets; all line-height tokens maintain an expansive 1.5× to 1.8× multiplier to eliminate diacritic collision.
- **Numerals & Currency:** Always format monetary amounts with native Eastern-Arabic numerals (`۰۱۲۳۴۵۶۷۸۹`) coupled with a smaller, medium-weighted currency token (`تومان`).
- **Editorial Microcopy:** Category metadata and sub-captions maintain a 300 to 400 weight paired with `#81767A` to preserve page quietude.

## Layout & Spacing

Layouts adopt a fluid 12-column grid on desktop screens down to a 4-column responsive grid on mobile, honoring strict right-to-left layout axes.

### Grid & Breakpoints
- **Desktop (1280px+):** 12 columns, `gutter: 1.5rem`, `margin: 3rem`, maximum page constraint capped at 1440px for editorial reading comfort.
- **Tablet (768px - 1279px):** 8 columns, `gutter: 1.25rem`, `margin: 2rem`.
- **Mobile (320px - 767px):** 4 columns, `gutter-mobile: 0.75rem`, `margin-mobile: 1.25rem`.

### Spatial Rhythm
Product grids use staggered aspect ratios (4:5 vertical proportions) accompanied by generous vertical section pacing (`space-2xl`) to evoke lookbook browsing rather than dense commodity listing.

## Elevation & Depth

Visual hierarchy uses warm, plum-tinted ambient diffusion instead of standard cold carbon shadows.

### Shadow Scale
- **Flat Surface:** `border: 1px solid #EFE6E9`, background `#FFFFFF`.
- **Subtle Elevation (Cards & Product Tiles):**
  - Rest: `box-shadow: 0 4px 20px -4px rgba(81, 43, 58, 0.04), 0 1px 3px 0 rgba(81, 43, 58, 0.02)`
  - Hover: `box-shadow: 0 12px 32px -6px rgba(81, 43, 58, 0.08), 0 2px 6px 0 rgba(81, 43, 58, 0.03)`
  - Border transition: Shifts from `#EFE6E9` to `#F0D3DC`.
- **Floating Overlays (Flyout Cart, Modal Sheets):**
  - `box-shadow: 0 24px 48px -12px rgba(81, 43, 58, 0.12), 0 4px 12px -2px rgba(81, 43, 58, 0.04)`
  - Backdrop blur: `backdrop-filter: blur(8px); background-color: rgba(255, 252, 248, 0.85)`

## Shapes

The form language balances structural rigor with soft cosmetic curvature. Radii span from **8px (`0.5rem`)** on interactive tiles up to pill silhouettes (**9999px**) on promotional badges and filter chips.

- **Base Radii (`0.5rem` / 8px):** Form fields, standard product cards, nested media wrappers.
- **Elevated Radii (`1rem` / 16px):** Dialog sheets, dropdown flyouts, carousel focus cards.
- **Pill (`9999px`):** CTAs, filter chips, perfume note pills, and notification indicators.

## Components

### Buttons
- **Primary Button:** Deep Rose (`#A94F70`) fill, white text (`#FFFFFF`), fully rounded pill shape (`9999px`), padding `0.875rem 2rem`. On hover, transitions to Deep Plum (`#512B3A`) with a subtle `translateY(-1px)`.
- **Secondary Button:** Warm Ivory (`#FFFCF8`) fill, 1px solid border in `#F0D3DC`, text in `#512B3A`. Hover initiates `#F5E6EA` background fill and border tint `#A94F70`.
- **Tertiary / Text Action:** Transparent background, text in `#A94F70`, adorned with a subtle underline offset by 6px using `#B88A7A`.

### Product Cards
- **Structure:** 4:5 image container framed within a 1px `#EFE6E9` border on `#FFFFFF` ground.
- **Meta Hierarchy:**
  1. Micro brand tag in `#81767A` (label-md).
  2. Persian product title in `#512B3A` (title-md, max 2 lines).
  3. Pricing module: Discounted strike-through in `#81767A`, current price in `#A94F70` (price-numeral) followed by currency affix `تومان`.
- **Wishlist Action:** Floated top-left (for RTL viewing rhythm), 36px circular ivory icon-button with plum icon outline.

### Chips & Filter Tags
- **Filter Chip:** Pill-shaped border `1px solid #EFE6E9`, background `#FFFCF8`, text `#81767A`.
- **Selected State:** Border `#A94F70`, background `#F5E6EA`, text `#A94F70`, with an integrated dismiss glyph on the left edge.

### Form Inputs & Text Fields
- **Container:** Height `3.25rem`, radius `0.5rem`, background `#FFFFFF`, border `1px solid #EFE6E9`.
- **Text Alignment:** Right-aligned placeholder and text input, padded by `1rem` on each side.
- **Focus State:** 1px outline in `#A94F70` paired with `box-shadow: 0 0 0 3px rgba(169, 79, 112, 0.12)`.
- **Helper & Validation:** Error messages render in `#A94F70`, warnings in `#B88A7A`.

### Selection Controls
- **Radio Buttons & Checkboxes:** Custom rounded selectors (radius 4px for checkboxes, 50% for radios), active color `#A94F70`, check indicator rendered in pure white. Inactive border `#EFE6E9`.

### Specialized Beauty Components
- **Shade Selector Swatches:** 28px circular swatches wrapped in a 2px offset border (`#FFFCF8`), activating a 1.5px solid outer ring in `#A94F70` upon selection.
- **Editorial Fragrance Note Badges:** Borderless `#F5E6EA` capsules with `#512B3A` typography, conveying top, heart, and base notes.
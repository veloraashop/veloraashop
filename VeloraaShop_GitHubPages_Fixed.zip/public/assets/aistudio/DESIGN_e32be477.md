---
name: Persian Luxury Editorial
colors:
  surface: '#fff8f9'
  surface-dim: '#e8d5dd'
  surface-bright: '#fff8f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff0f5'
  surface-container: '#fce9f1'
  surface-container-high: '#f6e3eb'
  surface-container-highest: '#f1dee6'
  on-surface: '#23191e'
  on-surface-variant: '#534247'
  inverse-surface: '#392d33'
  inverse-on-surface: '#ffecf4'
  outline: '#867278'
  outline-variant: '#d8c1c7'
  surface-tint: '#974065'
  primary: '#742348'
  on-primary: '#ffffff'
  primary-container: '#913b60'
  on-primary-container: '#ffbfd4'
  inverse-primary: '#ffb0cc'
  secondary: '#894b61'
  on-secondary: '#ffffff'
  secondary-container: '#feb1ca'
  on-secondary-container: '#7b4055'
  tertiary: '#5d3645'
  on-tertiary: '#ffffff'
  tertiary-container: '#784c5c'
  on-tertiary-container: '#f9c1d4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9e4'
  primary-fixed-dim: '#ffb0cc'
  on-primary-fixed: '#3e0020'
  on-primary-fixed-variant: '#7a294d'
  secondary-fixed: '#ffd9e3'
  secondary-fixed-dim: '#feb1ca'
  on-secondary-fixed: '#38091e'
  on-secondary-fixed-variant: '#6d344a'
  tertiary-fixed: '#ffd9e4'
  tertiary-fixed-dim: '#efb7ca'
  on-tertiary-fixed: '#31101e'
  on-tertiary-fixed-variant: '#633b4a'
  background: '#fff8f9'
  on-background: '#23191e'
  surface-variant: '#f1dee6'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 3.5rem
    fontWeight: '700'
    lineHeight: 4.25rem
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 3rem
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 3rem
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.5rem
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2.25rem
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.875rem
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.75rem
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 2rem
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.5rem
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
  price-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '700'
    lineHeight: 2rem
  price-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '700'
    lineHeight: 1.5rem
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-tablet: 2rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses a refined, contemporary Persian luxury aesthetic tailored for high-end beauty e-commerce. Drawing from modern editorial layout principles and soft tactile warmth, the visual language balances generous whitespace with rich, velvety burgundy and rose undertones.

The brand targets discerning beauty connoisseurs seeking premium skincare, fragrances, and cosmetics. Interactions and visuals evoke sensory indulgence, understated opulence, and serene confidence. The interface prioritizes breathable compositions over dense commercial grids, ensuring photography and product craftsmanship remain central.

Native Right-to-Left (RTL) mechanics inform all layout balances, reading paths, and micro-interactions. The experience blends editorial restraint with tactile softness—employing subtle warm borders, delicate surface tinting, and whisper-soft plum-tinted ambient depth.

## Colors

The palette establishes an opulent, warm cosmetic ambience anchored by deep berry and soft rose notes set against an ivory background.

- **Primary (`#913B60`)**: Deep royal burgundy used for core conversion points, active navigation states, primary buttons, and critical accents. Interactive hover states deepen to `#7B2F4F`.
- **Secondary (`#D88FA7`)**: Delicate rose accent utilized for seasonal badges, secondary interactive states, category highlights, and decorative flourishes.
- **Tertiary / Text Accent (`#512B3A`)**: Deep plum providing intense contrast for editorial titles, elevated badge borders, and focused highlights.
- **Neutral / Text Primary (`#30252B`)**: Deep espresso charcoal delivering high-legibility typographic contrast without the stark harshness of pure black.
- **Text Secondary (`#776B70`)**: Muted plum-gray dedicated to secondary product specs, meta details, hints, and breadcrumbs.
- **Surfaces**:
  - Main background: `#FFFCF8` (Warm ivory creating an organic, linen-like foundation).
  - Subtle containers: `#F8E9EE` (Pale blush for filter panels, notification banners, and section bandings).
  - Cards & dialogs: `#FFFFFF` (Pure white for raised product planes).
  - Hover & selection: `#F0D3DC` (Soft petal pink indicating interactive feedback).
- **Borders & Dividers (`#EADDE1`)**: Warm rose-gray delivering subtle structure without visual noise.

## Typography

The typographic hierarchy prioritizes Persian RTL text rendering with graceful proportions, ample line heights, and refined numeral styling. When serving Persian script in production, configure the system font stack to map directly to `Vazirmatn`, `Estedad`, or equivalent contemporary Persian geometric sans-serifs, with `Plus Jakarta Sans` serving Latin and fallback glyphs.

Key typographic rules:
- **Directionality & Flow**: Default direction is `dir="rtl"`. Text alignments default to `right`. Icons that convey direction (arrows, chevrons, flow steps) must mirror horizontally across the vertical axis.
- **Leading & Line-Height**: Persian script requires 15–25% higher line-height ratios than Latin to preserve the integrity of diacritics, ascenders, and descenders. Body text maintains a minimum line height of `1.75rem` for `1rem` font sizing.
- **Numerals & Currency**: Prices always pair bold Persian numerals with the currency unit (تومان / Toman). The currency label renders at `0.75rem` to `0.875rem` with `font-weight: 500`, positioned after the numeral in reading order.
- **Letter Spacing**: Avoid tracking expansion on Persian connected scripts; negative or positive tracking is strictly limited to Latin display instances.

## Layout & Spacing

The layout is structured around an editorial fluid grid calibrated to showcase premium cosmetics through balanced whitespace.

### Grid Hierarchy
- **Desktop (>= 1280px)**: 12-column grid, max-width `1360px`, `3rem` (`48px`) outer margin, `1.5rem` (`24px`) gutter. Product catalog grids employ 3 or 4 columns.
- **Tablet (768px – 1279px)**: 8-column grid, `2rem` (`32px`) outer margin, `1.5rem` (`24px`) gutter. Product catalogs reflow to 2 or 3 columns.
- **Mobile (< 768px)**: 4-column grid, `1.25rem` (`20px`) outer margin, `1rem` (`16px`) gutter. Product catalogs reflow to a 2-column compact grid or single-column curated showcase.

### Layout Principles
- **Generous Section Breaks**: Between major narrative sections, apply `4rem` to `6rem` vertical padding to avoid cluttered mass-merchant visual density.
- **Asymmetric Feature Moments**: Editorial modules feature alternating wide image panels with adjacent offset text cards, breaking rigid e-commerce modularity.
- **RTL Alignment Anchors**: Main visual gravity aligns along the right axis. Filters, side drawers, and off-canvas carts deploy from the right side of the screen.

## Elevation & Depth

Visual depth is achieved through gentle tonal stepping combined with tinted ambient illumination rather than harsh, dark drop shadows.

### Atmospheric Shadow Palette
All elevations incorporate the warm plum pigment of the brand palette (`rgba(81, 43, 58, ...)`):
- **Level 0 (Flat)**: Baseline background (`#FFFCF8`). No shadow. Borders (`1px solid #EADDE1`) define subtle structural delineation.
- **Level 1 (Card Rest)**: `box-shadow: 0 4px 20px -2px rgba(81, 43, 58, 0.05)`. Used for resting product tiles and container panels on pure white surfaces.
- **Level 2 (Card Hover & Interactive)**: `box-shadow: 0 10px 30px -4px rgba(81, 43, 58, 0.08)`. Subtle elevation lift for focused or hovered cards.
- **Level 3 (Sticky Nav & Drawers)**: `box-shadow: 0 8px 32px 0 rgba(81, 43, 58, 0.08)`. Utilized for floating headers, filter bars, and quick-add overlays.
- **Level 4 (Modals & Lightboxes)**: `box-shadow: 0 24px 48px -8px rgba(81, 43, 58, 0.14)`. Reserved for modal dialogues, cart sheets, and shade-finder overlays.

### Translucency & Frosted Glass
Sticky navigation headers and floating quick-filter capsules employ subtle glassmorphic backing: `background-color: rgba(255, 252, 248, 0.85); backdrop-filter: blur(12px)`.

## Shapes

The design system adopts a calibrated roundedness that expresses cosmetic softness while preserving architectural discipline:

- **Cards & Surfaces (`12px` / `0.75rem`)**: Applied to product cards, testimonial containers, informational banners, and review blocks.
- **Interactive Controls (`8px` / `0.5rem`)**: Buttons, text inputs, dropdown triggers, and quantity selectors use an 8px radius for crisp, responsive utility.
- **Pills & Badges (`9999px` / Full Pill)**: Category chips, discount tags, shade selectors, status markers, and search capsules are fully rounded pills.
- **Imagery**: Product portrait photos use matching `12px` corner radii or can bleed flush to card edges with identical top corner masking.

## Components

### Buttons
- **Primary**: Background `#913B60`, text `#FFFFFF`, border `none`, border radius `8px`. Height `48px` (desktop), `44px` (mobile). Hover shifts background to `#7B2F4F`. Focused state displays a `2px` ring in `#D88FA7` with `2px` offset.
- **Secondary / Ghost**: Background `transparent`, border `1.5px solid #913B60`, text `#913B60`. Hover background `#F8E9EE`.
- **Soft Accent**: Background `#F8E9EE`, text `#913B60`. Hover background `#F0D3DC`.
- **Icon Placement**: In RTL layout, leading icons render to the right of the button label; trailing icons (like checkout arrows) render to the left, pointing leftwards (`←`).

### Cards (Product Card)
- **Container**: Surface `#FFFFFF`, border `1px solid #EADDE1`, border radius `12px`, padding `space-md` (`16px`). Resting shadow: Level 1.
- **Image Area**: Aspect ratio 4:5 or 1:1, centered product render on neutral `#FAF5F7` backdrop, rounded top corners `8px`.
- **Badges**: Pill-shaped (`9999px`), positioned top-right (RTL start), using `#F8E9EE` background and `#512B3A` text.
- **Price Display**: Numerals set in `price-md` with currency unit suffix `تومان`. Old/strikethrough prices in `#776B70`.

### Form Inputs & Selectors
- **Input Field**: Height `48px`, background `#FFFFFF`, border `1px solid #EADDE1`, border radius `8px`, horizontal padding `16px`. Text `#30252B`, placeholder `#776B70`. Focus transition: border `#913B60`, box-shadow `0 0 0 3px #F8E9EE`.
- **Labeling**: Text positioned above the input, aligned right (`label-lg`), color `#30252B`.

### Chips & Filters
- **Resting**: Height `36px`, pill radius (`9999px`), background `#FFFFFF`, border `1px solid #EADDE1`, text `#776B70`, padding `0 16px`.
- **Selected**: Background `#913B60`, border `1px solid #913B60`, text `#FFFFFF`.
- **Counter**: Small pill badge appended to the left of the label inside the chip with background `#F8E9EE` and text `#512B3A`.

### Selection Controls
- **Radio Buttons**: `20px` diameter circle. Selected state shows `#913B60` outer ring with an inner `#913B60` dot separated by a `2px` white gap.
- **Checkboxes**: `20px` square with `4px` radius. Active state fills with `#913B60`, displaying a crisp white checkmark icon.

### Swatches & Shade Selectors
- Circular `32px` color disks with a `1px` subtle border. Selected swatch features a `2px` ring in `#913B60` with a `2px` gap (`#FFFFFF` spacer) around the circle.

### Lists & Dividers
- List items feature subtle bottom dividers (`1px solid #EADDE1`). Navigation lists use subtle right-aligned active indicators (`3px` vertical burgundy strip on the right edge).